chmod +x go
./go